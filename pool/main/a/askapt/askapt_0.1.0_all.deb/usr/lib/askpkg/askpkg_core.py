#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as _dt
import difflib
import gzip
import hashlib
import os
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

VERSION = "0.1.0"


class AskPkgError(RuntimeError):
    pass


def run(cmd: list[str], *, cwd: Path | None = None, check: bool = True, capture: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
        check=check,
    )


def need(command: str, hint: str | None = None) -> str:
    path = shutil.which(command)
    if not path:
        msg = f"Missing required command: {command}"
        if hint:
            msg += f"\n{hint}"
        raise AskPkgError(msg)
    return path


def sanitize_pkg_name(value: str) -> str:
    value = value.strip().lower().replace("_", "-")
    value = re.sub(r"[^a-z0-9+.-]+", "-", value).strip("-.")
    if not value:
        raise AskPkgError("Package name cannot be empty.")
    if not re.match(r"^[a-z0-9]", value):
        value = "pkg-" + value
    return value


def sanitize_cmd_name(value: str) -> str:
    value = value.strip().replace(" ", "-")
    value = re.sub(r"[^A-Za-z0-9._+-]+", "-", value).strip("-.")
    if not value:
        raise AskPkgError("Command name cannot be empty.")
    return value


def prompt(label: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    return value or default


def yes_no(label: str, default: bool = True) -> bool:
    hint = "Y/n" if default else "y/N"
    while True:
        value = input(f"{label} [{hint}] ").strip().lower()
        if not value:
            return default
        if value in {"y", "yes"}:
            return True
        if value in {"n", "no"}:
            return False
        if value in {"exit", "quit", "q"}:
            raise KeyboardInterrupt




def admin_command(cmd: list[str]) -> list[str]:
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return cmd
    need("sudo", "Run as root or install/configure sudo for package-management actions.")
    return ["sudo", *cmd]

def hash_file(path: Path, algorithm: str) -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


@dataclass
class Candidate:
    name: str
    version: str = ""
    description: str = ""
    repo: str = ""


def rank_candidates(query: str, candidates: Iterable[Candidate]) -> list[Candidate]:
    q = query.lower().strip()

    def score(c: Candidate):
        n = c.name.lower()
        d = c.description.lower()
        exact = 0 if n == q else 1
        starts = 0 if n.startswith(q) else 1
        contains = 0 if q in n else 1
        sim = difflib.SequenceMatcher(None, q, n).ratio()
        desc = 0 if q in d else 1
        return (exact, starts, contains, desc, -sim, len(n))

    return sorted(candidates, key=score)


class Backend:
    name = "base"
    command = "askpkg"

    def search(self, query: str) -> list[Candidate]:
        raise NotImplementedError

    def install(self, package: str) -> int:
        raise NotImplementedError

    def remove(self, package: str) -> int:
        raise NotImplementedError

    def update(self) -> int:
        raise NotImplementedError


class AptBackend(Backend):
    name = "apt"
    command = "askapt"

    def search(self, query: str) -> list[Candidate]:
        need("apt-cache", "On Debian/Ubuntu, apt-cache is provided by apt.")
        proc = run(["apt-cache", "--names-only", "search", query], check=False)
        if not proc.stdout.strip():
            proc = run(["apt-cache", "search", query], check=False)
        out: list[Candidate] = []
        seen: set[str] = set()
        for line in proc.stdout.splitlines():
            if " - " not in line:
                continue
            name, desc = line.split(" - ", 1)
            name = name.strip()
            if not name or name in seen:
                continue
            seen.add(name)
            out.append(Candidate(name=name, description=desc.strip()))
        return rank_candidates(query, out)

    def details(self, package: str) -> Candidate:
        proc = run(["apt-cache", "show", package], check=False)
        version = ""
        desc = ""
        for line in proc.stdout.splitlines():
            if line.startswith("Version:") and not version:
                version = line.split(":", 1)[1].strip()
            elif line.startswith("Description:") and not desc:
                desc = line.split(":", 1)[1].strip()
        return Candidate(package, version, desc)

    def install(self, package: str) -> int:
        return subprocess.call(admin_command(["apt", "install", package]))

    def remove(self, package: str) -> int:
        return subprocess.call(admin_command(["apt", "remove", package]))

    def update(self) -> int:
        return subprocess.call(admin_command(["apt", "update"]))


class PacmanBackend(Backend):
    name = "pacman"
    command = "askpac"

    def search(self, query: str) -> list[Candidate]:
        need("pacman", "AskPac is intended for Arch Linux and pacman-based systems.")
        proc = run(["pacman", "-Ss", "--color", "never", query], check=False)
        out: list[Candidate] = []
        current: Candidate | None = None
        for line in proc.stdout.splitlines():
            if line.startswith(" ") or line.startswith("\t"):
                if current and not current.description:
                    current.description = line.strip()
                continue
            m = re.match(r"([^/\s]+)/([^\s]+)\s+([^\s]+)", line)
            if not m:
                continue
            repo, name, version = m.groups()
            current = Candidate(name=name, version=version, repo=repo)
            out.append(current)
        return rank_candidates(query, out)

    def install(self, package: str) -> int:
        return subprocess.call(admin_command(["pacman", "-S", package]))

    def remove(self, package: str) -> int:
        return subprocess.call(admin_command(["pacman", "-Rns", package]))

    def update(self) -> int:
        return subprocess.call(admin_command(["pacman", "-Syu"]))


def choose_candidate(backend: Backend, query: str, *, install: bool = True) -> int:
    candidates = backend.search(query)
    if not candidates:
        print(f"No packages found for: {query}")
        return 1

    rejected: set[str] = set()
    for c in candidates:
        if c.name in rejected:
            continue
        print("\nFound:")
        print(f"  Package: {c.name}")
        if c.repo:
            print(f"  Repo: {c.repo}")
        if c.version:
            print(f"  Version: {c.version}")
        if c.description:
            print(f"  Description: {c.description}")
        while True:
            answer = input("Is this what you meant? [y/n/exit] ").strip().lower()
            if answer in {"exit", "quit", "q"}:
                return 0
            if answer in {"n", "no"}:
                rejected.add(c.name)
                break
            if answer in {"y", "yes"}:
                if install:
                    print(f"\nInstalling {c.name}...")
                    return backend.install(c.name)
                return 0
            print("Type y, n, or exit.")

    print("No more matching packages.")
    return 1


def interactive_shell(backend: Backend) -> int:
    print(f"{backend.command} {VERSION}")
    print("Type a package/app name to find and install it. Type 'exit' to quit.\n")
    while True:
        try:
            q = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if not q:
            continue
        if q.lower() in {"exit", "quit", "q"}:
            return 0
        choose_candidate(backend, q, install=True)


@dataclass
class BuildMeta:
    package: str
    version: str
    description: str
    command: str
    maintainer: str
    dependencies: list[str]
    target: Path
    entry: Path
    kind: str


def detect_entry(target: Path) -> tuple[Path, str]:
    if target.is_file():
        suffix = target.suffix.lower()
        if suffix == ".py":
            return target, "python"
        if suffix in {".sh", ".bash"}:
            return target, "shell"
        return target, "binary"

    if not target.is_dir():
        raise AskPkgError(f"Target does not exist: {target}")

    priorities = ["main.py", "app.py", "run.py", "main.sh", "run.sh"]
    for name in priorities:
        p = target / name
        if p.is_file():
            return p, "python" if p.suffix == ".py" else "shell"

    candidates = sorted([p for p in target.iterdir() if p.is_file() and p.suffix.lower() in {".py", ".sh"}])
    if len(candidates) == 1:
        p = candidates[0]
        return p, "python" if p.suffix == ".py" else "shell"

    if candidates:
        print("Choose the app entry file:")
        for i, p in enumerate(candidates, 1):
            print(f"  {i}. {p.name}")
        while True:
            raw = input("Entry number: ").strip()
            if raw.isdigit() and 1 <= int(raw) <= len(candidates):
                p = candidates[int(raw) - 1]
                return p, "python" if p.suffix == ".py" else "shell"

    raise AskPkgError("Could not detect an entry file. Use a project with main.py/app.py/run.py/main.sh/run.sh, or pass a single script/binary.")


def collect_meta(target: Path, args) -> BuildMeta:
    entry, kind = detect_entry(target)
    default_pkg = sanitize_pkg_name(target.stem if target.is_file() else target.name)
    default_cmd = sanitize_cmd_name(entry.stem if target.is_file() else default_pkg)

    package = sanitize_pkg_name(args.name or prompt("Package name", default_pkg))
    version = args.version or prompt("Version", "1.0.0")
    description = args.description or prompt("Description", f"Packaged with {args.tool_name}")
    command = sanitize_cmd_name(args.command or prompt("Command name", default_cmd))
    maintainer = args.maintainer or prompt("Maintainer", os.environ.get("USER", "AskPkg user"))

    dep_raw = args.depends if args.depends is not None else prompt(
        "Extra system dependencies (comma-separated)",
        ""
    )
    deps = [d.strip() for d in dep_raw.split(",") if d.strip()]
    if kind == "python" and "python3" not in deps and "python" not in deps:
        deps.insert(0, "python3")

    return BuildMeta(package, version, description, command, maintainer, deps, target.resolve(), entry.resolve(), kind)


def copy_payload(meta: BuildMeta, payload_dir: Path) -> Path:
    payload_dir.mkdir(parents=True, exist_ok=True)
    if meta.target.is_file():
        dst = payload_dir / meta.target.name
        shutil.copy2(meta.target, dst)
        return Path(meta.target.name)

    dst_root = payload_dir / "app"
    shutil.copytree(meta.target, dst_root, dirs_exist_ok=True)
    rel = meta.entry.relative_to(meta.target)
    return Path("app") / rel


def make_wrapper(kind: str, installed_entry: str) -> str:
    if kind == "python":
        return f"#!/bin/sh\nexec python3 {shlex.quote(installed_entry)} \"$@\"\n"
    if kind == "shell":
        return f"#!/bin/sh\nexec /bin/sh {shlex.quote(installed_entry)} \"$@\"\n"
    return f"#!/bin/sh\nexec {shlex.quote(installed_entry)} \"$@\"\n"


def build_deb(meta: BuildMeta, out_root: Path, make_repo: bool) -> Path:
    need("dpkg-deb", "Install Debian's dpkg tools before building a .deb.")
    with tempfile.TemporaryDirectory(prefix=f"askapt-{meta.package}-") as tmp:
        work = Path(tmp)
        root = work / "root"
        control_dir = root / "DEBIAN"
        app_dir = root / "usr" / "lib" / meta.package
        bin_dir = root / "usr" / "bin"
        control_dir.mkdir(parents=True)
        app_dir.mkdir(parents=True)
        bin_dir.mkdir(parents=True)
        control_dir.chmod(0o755)

        payload_tmp = work / "payload"
        rel_entry = copy_payload(meta, payload_tmp)
        for item in payload_tmp.iterdir():
            dst = app_dir / item.name
            if item.is_dir():
                shutil.copytree(item, dst)
            else:
                shutil.copy2(item, dst)

        installed_entry = f"/usr/lib/{meta.package}/{rel_entry.as_posix()}"
        wrapper = bin_dir / meta.command
        wrapper.write_text(make_wrapper(meta.kind, installed_entry), encoding="utf-8")
        wrapper.chmod(0o755)

        arch = "all" if meta.kind in {"python", "shell"} else (run(["dpkg", "--print-architecture"]).stdout.strip() if shutil.which("dpkg") else "amd64")
        deps = list(meta.dependencies)
        if meta.kind == "python":
            deps = ["python3" if d == "python" else d for d in deps]
        control = [
            f"Package: {meta.package}",
            f"Version: {meta.version}",
            f"Architecture: {arch}",
            f"Maintainer: {meta.maintainer}",
        ]
        if deps:
            control.append("Depends: " + ", ".join(deps))
        control += [
            f"Description: {meta.description}",
            " Built automatically by AskApt.",
            "",
        ]
        control_file = control_dir / "control"
        control_file.write_text("\n".join(control), encoding="utf-8")
        control_file.chmod(0o644)

        dist = out_root / "dist"
        dist.mkdir(parents=True, exist_ok=True)
        deb = dist / f"{meta.package}_{meta.version}_{arch}.deb"
        proc = run(["dpkg-deb", "--build", "--root-owner-group", str(root), str(deb)], check=False)
        if proc.returncode != 0:
            raise AskPkgError(proc.stderr or proc.stdout or "dpkg-deb failed")

    print(f"Built: {deb}")
    if make_repo:
        repo = build_apt_repo(deb, meta, out_root)
        print(f"APT repo: {repo}")
    return deb

def deb_fields(deb: Path) -> dict[str, str]:
    proc = run(["dpkg-deb", "-f", str(deb)], check=True)
    fields: dict[str, str] = {}
    current = None
    for line in proc.stdout.splitlines():
        if line.startswith(" ") and current:
            fields[current] += "\n" + line
        elif ":" in line:
            k, v = line.split(":", 1)
            fields[k.strip()] = v.strip()
            current = k.strip()
    return fields


def build_apt_repo(deb: Path, meta: BuildMeta, out_root: Path) -> Path:
    repo = out_root / "apt-repo"
    if repo.exists():
        shutil.rmtree(repo)
    first = meta.package[0]
    pool = repo / "pool" / "main" / first / meta.package
    pool.mkdir(parents=True, exist_ok=True)
    target_deb = pool / deb.name
    shutil.copy2(deb, target_deb)

    host_arch = run(["dpkg", "--print-architecture"]).stdout.strip() if shutil.which("dpkg") else "amd64"
    idx_dir = repo / "dists" / "stable" / "main" / f"binary-{host_arch}"
    idx_dir.mkdir(parents=True, exist_ok=True)

    fields = deb_fields(target_deb)
    rel = target_deb.relative_to(repo).as_posix()
    package_lines = []
    ordered = ["Package", "Version", "Architecture", "Maintainer", "Depends", "Description"]
    for k in ordered:
        if fields.get(k):
            package_lines.append(f"{k}: {fields[k]}")
    package_lines += [
        f"Filename: {rel}",
        f"Size: {target_deb.stat().st_size}",
        f"MD5sum: {hash_file(target_deb, 'md5')}",
        f"SHA1: {hash_file(target_deb, 'sha1')}",
        f"SHA256: {hash_file(target_deb, 'sha256')}",
        "",
        "",
    ]
    packages = idx_dir / "Packages"
    packages.write_text("\n".join(package_lines), encoding="utf-8")
    with packages.open("rb") as src, gzip.open(idx_dir / "Packages.gz", "wb", compresslevel=9) as dst:
        shutil.copyfileobj(src, dst)

    release = repo / "dists" / "stable" / "Release"
    release.parent.mkdir(parents=True, exist_ok=True)
    date = _dt.datetime.now(_dt.timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    rel_files = [packages, idx_dir / "Packages.gz"]
    release_lines = [
        "Origin: AskApt",
        "Label: AskApt generated repository",
        "Suite: stable",
        "Codename: stable",
        f"Date: {date}",
        f"Architectures: {host_arch}",
        "Components: main",
        "Description: Repository generated by AskApt",
        "SHA256:",
    ]
    for f in rel_files:
        p = f.relative_to(release.parent).as_posix()
        release_lines.append(f" {hash_file(f, 'sha256')} {f.stat().st_size:16d} {p}")
    release.write_text("\n".join(release_lines) + "\n", encoding="utf-8")

    readme = repo / "README-REPO.txt"
    readme.write_text(
        "AskApt repository generated successfully.\n\n"
        "This v0.1 repository is UNSIGNED. For private/testing use, after hosting it over HTTPS,\n"
        "APT can be pointed at it with a source like:\n\n"
        "  deb [trusted=yes] https://YOUR-HOST/YOUR-PATH stable main\n\n"
        "Then run:\n"
        f"  sudo apt update\n  sudo apt install {meta.package}\n\n"
        "For public distribution, sign the Release metadata and distribute a signing key instead of using trusted=yes.\n",
        encoding="utf-8",
    )
    return repo


def make_payload_tar(meta: BuildMeta, work: Path) -> tuple[Path, Path]:
    payload_dir = work / "payload-src"
    rel_entry = copy_payload(meta, payload_dir)
    archive = work / "payload.tar.gz"
    with tarfile.open(archive, "w:gz") as tf:
        for item in payload_dir.iterdir():
            tf.add(item, arcname=f"payload/{item.name}")
    return archive, rel_entry


def arch_dep_names(meta: BuildMeta) -> list[str]:
    deps = list(meta.dependencies)
    converted = []
    for d in deps:
        if d == "python3":
            d = "python"
        if d not in converted:
            converted.append(d)
    if meta.kind == "python" and "python" not in converted:
        converted.insert(0, "python")
    return converted


def build_arch(meta: BuildMeta, out_root: Path, make_repo: bool) -> Path:
    need("makepkg", "On Arch, install/use the normal packaging toolchain (makepkg; base-devel is recommended). AskPac will not install it for you.")
    work = out_root / "build" / f"{meta.package}-{meta.version}-arch"
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    archive, rel_entry = make_payload_tar(meta, work)
    sha = hash_file(archive, "sha256")

    deps = arch_dep_names(meta)
    dep_line = "depends=(" + " ".join(shlex.quote(x) for x in deps) + ")" if deps else "depends=()"
    arch_value = "any" if meta.kind in {"python", "shell"} else os.uname().machine
    installed_entry = f"/usr/lib/{meta.package}/{rel_entry.as_posix()}"
    wrapper = make_wrapper(meta.kind, installed_entry)
    escaped_wrapper = wrapper.replace("'", "'\\''")
    desc = meta.description.replace("'", "'\\''")
    pkgbuild = f"""pkgname={meta.package}
pkgver={meta.version}
pkgrel=1
pkgdesc='{desc}'
arch=('{arch_value}')
url='https://example.invalid/{meta.package}'
license=('custom')
{dep_line}
source=('payload.tar.gz')
sha256sums=('{sha}')

package() {{
  install -dm755 \"$pkgdir/usr/lib/$pkgname\"
  cp -a \"$srcdir/payload/.\" \"$pkgdir/usr/lib/$pkgname/\"
  install -dm755 \"$pkgdir/usr/bin\"
  printf '%s' '{escaped_wrapper}' > \"$pkgdir/usr/bin/{meta.command}\"
  chmod 755 \"$pkgdir/usr/bin/{meta.command}\"
}}
"""
    (work / "PKGBUILD").write_text(pkgbuild, encoding="utf-8")
    proc = run(["makepkg", "-f", "--nodeps"], cwd=work, check=False, capture=False)
    if proc.returncode != 0:
        raise AskPkgError("makepkg failed. See the output above.")

    built = sorted(work.glob(f"{meta.package}-{meta.version}-1-*.pkg.tar.*"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not built:
        raise AskPkgError("makepkg completed but no package archive was found.")
    dist = out_root / "dist"
    dist.mkdir(parents=True, exist_ok=True)
    package = dist / built[0].name
    shutil.copy2(built[0], package)
    print(f"Built: {package}")
    if make_repo:
        repo = build_pacman_repo(package, meta, out_root)
        print(f"Pacman repo: {repo}")
    return package


def build_pacman_repo(package: Path, meta: BuildMeta, out_root: Path) -> Path:
    need("repo-add", "repo-add is required to create a pacman repository database. AskPac will not install it automatically.")
    repo = out_root / "pacman-repo"
    if repo.exists():
        shutil.rmtree(repo)
    repo.mkdir(parents=True)
    target = repo / package.name
    shutil.copy2(package, target)
    proc = run(["repo-add", str(repo / "askpkg.db.tar.gz"), str(target)], check=False, capture=False)
    if proc.returncode != 0:
        raise AskPkgError("repo-add failed.")
    (repo / "README-REPO.txt").write_text(
        "AskPac repository generated successfully.\n\n"
        "After hosting this directory over HTTPS, add something like this to /etc/pacman.conf:\n\n"
        "  [askpkg]\n"
        "  SigLevel = Optional TrustAll\n"
        "  Server = https://YOUR-HOST/YOUR-PATH\n\n"
        "Then run:\n"
        "  sudo pacman -Sy\n"
        f"  sudo pacman -S {meta.package}\n\n"
        "For public distribution, sign packages/repository metadata and use a stricter SigLevel.\n",
        encoding="utf-8",
    )
    return repo


def make_package(backend: Backend, args) -> int:
    target = Path(args.target).expanduser()
    if not target.exists():
        raise AskPkgError(f"Target does not exist: {target}")
    meta = collect_meta(target, args)
    out = Path(args.output).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    print("\nBuild plan:")
    print(f"  Package: {meta.package}")
    print(f"  Version: {meta.version}")
    print(f"  Command: {meta.command}")
    print(f"  Entry:   {meta.entry}")
    print(f"  Type:    {meta.kind}")
    print(f"  Repo:    {'yes' if args.repo else 'no'}")
    if not args.yes and not yes_no("Build this package?", True):
        return 0

    if isinstance(backend, AptBackend):
        build_deb(meta, out, args.repo)
    else:
        build_arch(meta, out, args.repo)
    return 0


def gaming_scan(backend: Backend, game: str) -> int:
    """Safe v0.1 scanner: no installs, no downloads, no system modifications."""
    print(f"AskPkg Gaming Safe Scan — {game}")
    print("v0.1 never installs, downloads, or changes system settings in gaming mode.\n")

    session = os.environ.get("XDG_SESSION_TYPE", "unknown")
    desktop = os.environ.get("XDG_CURRENT_DESKTOP", "unknown")
    print(f"Session: {session}")
    print(f"Desktop: {desktop}")

    if shutil.which("gamemoderun"):
        print("✓ GameMode detected: gamemoderun is available.")
    else:
        print("• GameMode not detected (AskPkg will not install it).")

    if shutil.which("nvidia-smi"):
        proc = run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"], check=False)
        gpu = proc.stdout.strip() or "NVIDIA GPU"
        print(f"✓ NVIDIA detected: {gpu}")
    elif Path("/sys/class/drm").exists():
        print("• DRM GPU devices detected.")

    key = game.lower()
    tips: list[str] = []
    if "minecraft" in key:
        tips += [
            "Use the Java version required by your Minecraft/mod-loader version.",
            "Avoid assigning nearly all system RAM to Minecraft; leave memory for Linux and the desktop.",
            "Lower render distance/shader quality first when GPU-limited.",
        ]
    elif "rocket" in key:
        tips += [
            "If running through Steam/Proton, test a current Proton version and keep a working version available for rollback.",
            "Use fullscreen and check that the game is using the intended GPU.",
        ]
    else:
        tips += [
            "Use fullscreen or borderless mode and confirm the intended GPU is active.",
            "Close unnecessary heavy background apps before launching the game.",
        ]

    print("\nSafe suggestions:")
    for tip in tips:
        print(f"  - {tip}")
    print("\nOnline auto-optimization/downloads are intentionally disabled in v0.1 until a signed trusted-source system is added.")
    return 0


def parser_for(tool_name: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog=tool_name, description=f"{tool_name}: smart Linux package finder + package builder")
    p.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = p.add_subparsers(dest="subcommand")

    s = sub.add_parser("search", help="Search packages")
    s.add_argument("query", nargs="+")
    s.add_argument("--limit", type=int, default=10)

    i = sub.add_parser("install", help="Find a package, confirm it, then install")
    i.add_argument("query", nargs="+")

    r = sub.add_parser("remove", help="Remove an exact package name")
    r.add_argument("package")

    sub.add_parser("update", help="Run the distro package index/system update command")

    m = sub.add_parser("make", help="Build a .deb or Arch package from a script/app")
    m.add_argument("target")
    m.add_argument("--repo", action="store_true", help="Also generate repository metadata")
    m.add_argument("--output", default="askpkg-output")
    m.add_argument("--name")
    m.add_argument("--version", dest="version_value")
    m.add_argument("--description")
    m.add_argument("--command")
    m.add_argument("--maintainer")
    m.add_argument("--depends", default=None, help="Comma-separated system package dependencies")
    m.add_argument("-y", "--yes", action="store_true", help="Skip final build confirmation")

    g = sub.add_parser("gaming", help="Safe no-install gaming optimization scan")
    g.add_argument("game", nargs="+")
    return p


def main(tool_name: str) -> int:
    backend: Backend = AptBackend() if tool_name == "askapt" else PacmanBackend()
    parser = parser_for(tool_name)
    raw = sys.argv[1:]
    known = {"search", "install", "remove", "update", "make", "gaming", "-h", "--help", "--version"}
    if raw and raw[0] not in known and not raw[0].startswith("-"):
        return choose_candidate(backend, " ".join(raw), install=True)
    args = parser.parse_args()

    if args.subcommand is None:
        return interactive_shell(backend)

    if args.subcommand == "search":
        query = " ".join(args.query)
        results = backend.search(query)[: max(1, args.limit)]
        if not results:
            print("No packages found.")
            return 1
        for c in results:
            prefix = f"{c.repo}/" if c.repo else ""
            ver = f" {c.version}" if c.version else ""
            print(f"{prefix}{c.name}{ver}")
            if c.description:
                print(f"  {c.description}")
        return 0

    if args.subcommand == "install":
        return choose_candidate(backend, " ".join(args.query), install=True)
    if args.subcommand == "remove":
        return backend.remove(args.package)
    if args.subcommand == "update":
        return backend.update()
    if args.subcommand == "gaming":
        return gaming_scan(backend, " ".join(args.game))
    if args.subcommand == "make":
        # argparse already uses --version globally, so map builder version manually.
        args.version = args.version_value
        args.tool_name = tool_name
        return make_package(backend, args)
    return 0


def cli(tool_name: str) -> None:
    try:
        raise SystemExit(main(tool_name))
    except AskPkgError as e:
        print(f"Error: {e}", file=sys.stderr)
        raise SystemExit(2)
    except KeyboardInterrupt:
        print("\nCancelled.")
        raise SystemExit(130)
